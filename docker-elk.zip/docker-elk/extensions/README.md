Third-party extensions that enable extra integrations with the ELK stack.
